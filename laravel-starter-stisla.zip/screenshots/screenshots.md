# User Login
![Login](login.png)

# Register
![Register](register.png)

# Forgot Password
![Forgot](reset.png)

# Dashboard
![Dashboard](dashboard.png)

# User List
![UserList](userlist.png)

# Role
![Role](role.png)

# Permission
![Permission](permission.png)

# Permission To Role
![PermissionToRole](roletopermission.png)

# User To Role
![UserToRole](usertorole.png)

# Menu Group
![MenuGroup](menugroup.png)

# Menu Item
![MenuItem](menuitem.png)