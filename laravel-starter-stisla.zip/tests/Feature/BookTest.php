<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Http\UploadedFile;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class BookTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    use RefreshDatabase;

    public function test_create_book()
    {
        $this->seed();
        $user = User::find(1);
        $response = $this->actingAs($user);
        $response = $this->withSession(['*']);
        $response = $this->get("/book-management/book/create");
        $response->assertStatus(200);
        $response->assertSeeText('Tambah Book');
        $response->assertSeeText('ISBN');
        $response->assertSeeText('Title');
        $response->assertSeeText('Author');
        $response->assertSeeText('Book Image');
        $response->assertSeeText('Publication Date Book');
        $response->assertSeeText('Book File');
        $response->assertSeeText('User');
        $response = $this->post('book', [
            'isbn' => '987654321',
            'title' => 'terserah',
            'author' => 'jono',
            'image' => UploadedFile::fake()->image('bookimage.jpeg'),
            'publication_date' => now(),
            'file' => UploadedFile::fake()->create('book.pdf'),
            'user' => 1,
        ]);
        $response->assertRedirect('/book-management/book');
    }

    public function test_show_book()
    {
        $this->seed();
        $user = User::where('email','superadmin@gmail.com')->first();
        $response = $this->actingAs($user);
        $response = $this->withSession(['*']);
        $response = $this->get("/book-management/book");
        $response->assertStatus(200);
        $response->assertSeeText('Book List');
    }

    public function test_update_book()
    {
        $this->assertTrue(true);
    }

    public function test_delete_book()
    {
        $this->assertTrue(true);
    }
}
