<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="index.html"><?php echo e($title); ?></a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
        <a href="index.html">St</a>
    </div>
    <ul class="sidebar-menu">
        <?php $__currentLoopData = $menuGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($item->permission_name)): ?>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link has-dropdown"><i class="<?php echo e($item->icon); ?>"></i>
                        <span><?php echo e($item->name); ?></span></a>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $item->menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($menuItem->permission_name)): ?>
                                <li>
                                    <a class="nav-link " href="<?php echo e(url($menuItem->route)); ?>"><?php echo e($menuItem->name); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</aside>
<?php /**PATH E:\laravel project\laravel-starter-stisla\resources\views/components/sidebar.blade.php ENDPATH**/ ?>