<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\laravel project\laravel-starter-stisla\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>