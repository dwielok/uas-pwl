<div class="footer-left">
    Copyright &copy; <?php echo e(now()->year); ?> <div class="bullet"></div> Design By <a
        href="https://nauval.in/">Muhamad Nauval
        Azhar</a> Laravel Code By <a href="https://putraprima.id">Putra Prima Arhandi</a>
</div>
<div class="footer-right">
    2.3.0
</div>
<?php /**PATH E:\laravel project\laravel-starter-stisla\resources\views/layouts/footer.blade.php ENDPATH**/ ?>