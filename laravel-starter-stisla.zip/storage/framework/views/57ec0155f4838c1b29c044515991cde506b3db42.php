<?php echo e($slot); ?>

<?php /**PATH E:\laravel project\laravel-starter-stisla\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>